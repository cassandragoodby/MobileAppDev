//
//  ViewController.swift
//  AdventApp
//
//  Created by Cassandra Goodby on 10/3/17.
//  Copyright © 2017 Cassandra Goodby. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var imageToLoad : String = ""
    var captop : String = ""
    var capbottom : String = ""
    var audioPlayer = AVAudioPlayer()

    @IBAction func btn1(_ sender: UIButton) {
        imageToLoad = "xmas1"
//        imageToLoad = "star.gif"
        captop = "Oh holy"
        capbottom = "night"
    }
    @IBAction func btn2(_ sender: UIButton) {
        imageToLoad = "xmas2"
        captop = "Oh"
        capbottom = "Snap"
    }
    @IBAction func btn3(_ sender: UIButton) {
        imageToLoad = "xmas3"
        captop = "Rudolf the"
        capbottom = "Red nose reindeer"
    }
    @IBAction func btn4(_ sender: UIButton) {
        imageToLoad = "xmas4"
        captop = "The stockings"
        capbottom = "were hung"
    }
    @IBAction func btn5(_ sender: UIButton) {
        imageToLoad = "xmas5"
        captop = "Baby it's"
        capbottom = "cold outside"
    }
    @IBAction func btn6(_ sender: UIButton) {
        imageToLoad = "xmas6"
        captop = "Jingle all"
        capbottom = "the way"
    }
    @IBAction func btn7(_ sender: UIButton) {
        imageToLoad = "xmas7"
        captop = "Let it"
        capbottom = "Snow"
    }
    @IBAction func btn8(_ sender: UIButton) {
        imageToLoad = "xmas8"
        captop = "A very merry"
        capbottom = "christmas"
    }
    @IBAction func btn9(_ sender: UIButton) {
        imageToLoad = "xmas9"
        captop = "All is calm"
        capbottom = "all is bright"
    }
    @IBAction func btn10(_ sender: UIButton) {
        imageToLoad = "xmas10"
        captop = "tis the season"
        capbottom = "to be jolly"
    }
    @IBAction func btn11(_ sender: UIButton) {
        imageToLoad = "xmas11"
        captop = "May your"
        capbottom = "holidays be sweet"
    }
    @IBAction func btn12(_ sender: UIButton) {
        imageToLoad = "xmas12"
        captop = "Santa Claus"
        capbottom = "is coming to town"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let Scene2View = segue.destination as! Scene2ViewController
        
            Scene2View.naming.imageName = self.imageToLoad
            Scene2View.naming.top = self.captop
            Scene2View.naming.bottom = self.capbottom
        
    }
  
    
    @IBAction func unwindSegue(_ segue:UIStoryboardSegue){
        
    }
    
    
    override func viewDidLoad() {
        do{
            audioPlayer=try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath: Bundle.main.path(forResource: "Project4Final", ofType: "mp3")!))
            audioPlayer.prepareToPlay()
            audioPlayer.play()
            
            let audioSessions = AVAudioSession.sharedInstance()
            
            do{
                try audioSessions.setCategory(AVAudioSessionCategoryPlayback)
            }
        }
        catch{
            print(error)
        }
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

