//
//  Info.swift
//  AdventApp
//
//  Created by Cassandra Goodby on 10/17/17.
//  Copyright © 2017 Cassandra Goodby. All rights reserved.
//

import Foundation

class Info{
    var imageName : String?
    var top : String?
    var bottom : String?
    }

