//
//  Scene2ViewController.swift
//  AdventApp
//
//  Created by Cassandra Goodby on 10/5/17.
//  Copyright © 2017 Cassandra Goodby. All rights reserved.
//

import UIKit

class Scene2ViewController: UIViewController{
    @IBOutlet weak var imgxmas: UIImageView!
    @IBOutlet weak var caption1: UILabel!
    @IBOutlet weak var caption2: UILabel!
    
    var naming=Info()
//    var image : UIImage
    
    @IBAction func unwindSegue (_ segue:UIStoryboardSegue){
        
    }
    
    override func viewDidLoad() {
        caption1.text=naming.top
        caption2.text=naming.bottom
        //        imgxmas.image=UIImageView(image: naming.imageName)
        imgxmas.image=UIImage(named: naming.imageName!)
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
