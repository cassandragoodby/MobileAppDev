package com.example.cassandragoodby.proj2;

import android.content.Context;
import android.graphics.Typeface;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void submit(View view) {
        EditText wordChoice = (EditText) findViewById(R.id.editText);
        String wordValue = wordChoice.getText().toString();
        CheckBox checkBox1 = (CheckBox) findViewById(R.id.checkBox);
        CheckBox checkBox2 = (CheckBox) findViewById(R.id.checkBox2);
        CheckBox checkBox3 = (CheckBox) findViewById(R.id.checkBox3);
        Switch capitalSwitch = (Switch) findViewById(R.id.switch2);
        Button submitButton = (Button) findViewById(R.id.button);
        Button reset = (Button) findViewById(R.id.button3);
        SeekBar fontSize = (SeekBar) findViewById(R.id.seekBar2);
        TextView fontName = (TextView) findViewById(R.id.textView3);


//        TextView textShown = (TextView) findViewById(R.id.textView);
        TextView text = (TextView) findViewById(R.id.textView);




        if(wordValue.isEmpty()){
            //toast
            Context context = getApplicationContext();
            CharSequence textToast = "Please enter a word";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, textToast, duration);
            toast.show();
        }


        else if((checkBox1.isChecked()) || (checkBox2.isChecked()) || (checkBox3.isChecked())){
            wordChoice.setVisibility(View.INVISIBLE);
            submitButton.setVisibility(View.INVISIBLE);
            reset.setVisibility(View.VISIBLE);
            fontSize.setVisibility(View.VISIBLE);
            checkBox1.setVisibility(View.INVISIBLE);
            checkBox2.setVisibility(View.INVISIBLE);
            checkBox3.setVisibility(View.INVISIBLE);
            checkBox1.setVisibility(View.INVISIBLE);
            fontName.setVisibility(View.VISIBLE);
            if(capitalSwitch.isChecked()){
                wordValue = wordValue.toUpperCase();
                TextView textCap = (TextView) findViewById(R.id.textView);
                textCap.setText(wordValue);
            }
            else{
                wordValue.toLowerCase();
                TextView textCap = (TextView) findViewById(R.id.textView);
                textCap.setText(wordValue);

            }



            if(checkBox1.isChecked()){
                String[] fontArray = new String[5];
                    fontArray[0] = "abrahamlincoln.ttf";
                    fontArray[1] = "trocchi.otf";
                    fontArray[2] = "artifika.ttf";
                    fontArray[3] = "dubiel.ttf";
                    fontArray[4] = "abril.otf";
                int random = (int )(Math.random() * fontArray.length);
                Typeface font = Typeface.createFromAsset(getAssets(), fontArray[random]);
                text.setTypeface(font);
                String string = fontArray[random].substring(0, fontArray[random].length() - 4);
                fontName.setText("Font: "+string);

            }

            if(checkBox2.isChecked()){
                String[] fontArray = new String[5];
                    fontArray[0] = "bahaus.ttf";
                    fontArray[1] = "andes.ttf";
                    fontArray[2] = "aftershok.ttf";
                    fontArray[3] = "automania.TTF";
                    fontArray[4] = "blueprinted.ttf";
                int random = (int )(Math.random() * fontArray.length);
                Typeface font = Typeface.createFromAsset(getAssets(), fontArray[random]);
                text.setTypeface(font);
                String string = fontArray[random].substring(0, fontArray[random].length() - 4);
                fontName.setText("Font: "+string);
            }

            if(checkBox3.isChecked()){
                String[] fontArray = new String[5];
                    fontArray[0] = "autumn.ttf";
                    fontArray[1] = "mahogany.ttf";
                    fontArray[2] = "calligraphy.ttf";
                    fontArray[3] = "dohearts.otf";
                    fontArray[4] = "pacifico.ttf";
                int random = (int )(Math.random() * fontArray.length);
                Typeface font = Typeface.createFromAsset(getAssets(), fontArray[random]);
                text.setTypeface(font);
                String string = fontArray[random].substring(0, fontArray[random].length() - 4);
                fontName.setText("Font: "+string);
            }
            if(checkBox1.isChecked() && checkBox2.isChecked()){
                String[] fontArray = new String[10];
                fontArray[0] = "abrahamlincoln.ttf";
                fontArray[1] = "trocchi.otf";
                fontArray[2] = "artifika.ttf";
                fontArray[3] = "dubiel.ttf";
                fontArray[4] = "abril.otf";
                fontArray[5] = "bahaus.ttf";
                fontArray[6] = "andes.ttf";
                fontArray[7] = "aftershok.ttf";
                fontArray[8] = "automania.TTF";
                fontArray[9] = "blueprinted.ttf";
                int random = (int )(Math.random() * fontArray.length);
                Typeface font = Typeface.createFromAsset(getAssets(), fontArray[random]);
                text.setTypeface(font);
                String string = fontArray[random].substring(0, fontArray[random].length() - 4);
                fontName.setText("Font: "+string);
            }
            if(checkBox2.isChecked()&& checkBox3.isChecked()){
                String[] fontArray = new String[10];
                fontArray[0] = "bahaus.ttf";
                fontArray[1] = "andes.ttf";
                fontArray[2] = "aftershok.ttf";
                fontArray[3] = "automania.TTF";
                fontArray[4] = "blueprinted.ttf";
                fontArray[5] = "autumn.ttf";
                fontArray[6] = "mahogany.ttf";
                fontArray[7] = "calligraphy.ttf";
                fontArray[8] = "dohearts.otf";
                fontArray[9] = "pacifico.ttf";
                int random = (int )(Math.random() * fontArray.length);
                Typeface font = Typeface.createFromAsset(getAssets(), fontArray[random]);
                text.setTypeface(font);
                String string = fontArray[random].substring(0, fontArray[random].length() - 4);
                fontName.setText("Font: "+string);
            }
            if(checkBox1.isChecked() && checkBox3.isChecked()){
                String[] fontArray = new String[10];
                fontArray[0] = "abrahamlincoln.ttf";
                fontArray[1] = "trocchi.otf";
                fontArray[2] = "artifika.ttf";
                fontArray[3] = "dubiel.ttf";
                fontArray[4] = "abril.otf";
                fontArray[5] = "autumn.ttf";
                fontArray[6] = "mahogany.ttf";
                fontArray[7] = "calligraphy.ttf";
                fontArray[8] = "dohearts.otf";
                fontArray[9] = "pacifico.ttf";
                int random = (int )(Math.random() * fontArray.length);
                Typeface font = Typeface.createFromAsset(getAssets(), fontArray[random]);
                text.setTypeface(font);
                String string = fontArray[random].substring(0, fontArray[random].length() - 4);
                fontName.setText("Font: "+string);
            }
            if(checkBox1.isChecked() && checkBox2.isChecked() && checkBox3.isChecked()){
                String[] fontArray = new String[15];
                fontArray[0] = "abrahamlincoln.ttf";
                fontArray[1] = "trocchi.otf";
                fontArray[2] = "artifika.ttf";
                fontArray[3] = "dubiel.ttf";
                fontArray[4] = "abril.otf";
                fontArray[5] = "bahaus.ttf";
                fontArray[6] = "andes.ttf";
                fontArray[7] = "aftershok.ttf";
                fontArray[8] = "automania.TTF";
                fontArray[9] = "blueprinted.ttf";
                fontArray[10] = "autumn.ttf";
                fontArray[11] = "mahogany.ttf";
                fontArray[12] = "calligraphy.ttf";
                fontArray[13] = "dohearts.otf";
                fontArray[14] = "pacifico.ttf";
                int random = (int )(Math.random() * fontArray.length);
                Typeface font = Typeface.createFromAsset(getAssets(), fontArray[random]);
                text.setTypeface(font);
                String string = fontArray[random].substring(0, fontArray[random].length() - 4);
                fontName.setText("Font: "+string);
            }


        }

        else{
            //toast
            Context context = getApplicationContext();
            CharSequence textToast = "Please select a font type to include";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, textToast, duration);
            toast.show();
        }



    }

    public void reset(View view) {

        EditText wordChoice = (EditText) findViewById(R.id.editText);
        String wordValue = wordChoice.getText().toString();
        CheckBox checkBox1 = (CheckBox) findViewById(R.id.checkBox);
        CheckBox checkBox2 = (CheckBox) findViewById(R.id.checkBox2);
        CheckBox checkBox3 = (CheckBox) findViewById(R.id.checkBox3);
        Switch capitalSwitch = (Switch) findViewById(R.id.switch2);
        Button submitButton = (Button) findViewById(R.id.button);
        TextView text = (TextView) findViewById(R.id.textView);
        Button reset = (Button) findViewById(R.id.button3);
        TextView fontName = (TextView) findViewById(R.id.textView3);
        SeekBar fontSize = (SeekBar) findViewById(R.id.seekBar2);
        wordChoice.setVisibility(View.VISIBLE);
        text.setText("Include");
        submitButton.setVisibility(View.VISIBLE);
        reset.setVisibility(View.INVISIBLE);
        fontSize.setVisibility(View.INVISIBLE);
        checkBox1.setVisibility(View.VISIBLE);
        checkBox2.setVisibility(View.VISIBLE);
        checkBox3.setVisibility(View.VISIBLE);
        fontName.setVisibility(View.INVISIBLE);
        checkBox1.setVisibility(View.VISIBLE);
        Typeface font = Typeface.createFromAsset(getAssets(), "abrahamlincoln.ttf");
        text.setTypeface(font);
    }


}

