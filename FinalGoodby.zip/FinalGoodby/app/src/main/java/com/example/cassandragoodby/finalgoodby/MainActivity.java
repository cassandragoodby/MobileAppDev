package com.example.cassandragoodby.finalgoodby;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    private burritoPlace theBurritoPlace = new burritoPlace();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public void build(View view){
        EditText wordChoice = (EditText) findViewById(R.id.editText);
        Spinner location = (Spinner) findViewById(R.id.spinner);
        Integer place = location.getSelectedItemPosition();
        Switch glutenFree = (Switch) findViewById(R.id.gf);
        CheckBox salsa = (CheckBox) findViewById(R.id.salsa);
        CheckBox cheese = (CheckBox) findViewById(R.id.cheese);
        CheckBox sourCream = (CheckBox) findViewById(R.id.sourcream);
        CheckBox guacamole = (CheckBox) findViewById(R.id.guacamole);
        TextView showText = (TextView) findViewById(R.id.textView2);
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggle);
        ImageView image = (ImageView) findViewById(R.id.imageView);
        RadioButton burrito = (RadioButton) findViewById(R.id.burrito);
        RadioButton taco = (RadioButton) findViewById(R.id.taco);



        if(burrito.isChecked() || taco.isChecked()) {
            showText.setVisibility(View.VISIBLE);
            image.setVisibility(View.VISIBLE);
            String burritoName = wordChoice.getText().toString();
            showText.setText("The "+ burritoName+ " is a ");

            if (toggle.isChecked()) {
                showText.append("veggie ");
            } else {
                showText.append("meat ");
            }

            if (burrito.isChecked()) {
                image.setImageResource(R.drawable.burrito);
                showText.append("burrito with ");
            }
            if (taco.isChecked()) {
                image.setImageResource(R.drawable.taco);
                showText.append("taco with ");
            }

            if (salsa.isChecked()) {
                showText.append("salsa, ");
            }
            if (guacamole.isChecked()) {
                showText.append("guacamole, ");
            }
            if (cheese.isChecked()) {
                showText.append("cheese, ");
            }
            if (sourCream.isChecked()) {
                showText.append("sour cream, ");
            }
            if (glutenFree.isChecked()) {
                showText.append("in a corn tortilla ");
            }

            if (place == 0) {
                showText.append("that you would like to eat on The Hill. ");
            } else if (place == 1) {
                showText.append("that you would like to eat on Pearl Street. ");
            } else {
                showText.append("that you would like to eat on 29th Street. ");
            }
        }
        else{
            Context context = getApplicationContext();
            CharSequence textToast = "Please choose burrito or taco";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, textToast, duration);
            toast.show();
        }

    }
    public void find(View view){
        Spinner location = (Spinner) findViewById(R.id.spinner);
        Integer place = location.getSelectedItemPosition();
        ImageView image = (ImageView) findViewById(R.id.imageView);
        if(image.getVisibility() == View.VISIBLE){
            theBurritoPlace.setBurritoShop(place);
            String suggestedBurritoPlace = theBurritoPlace.getBurritoShop();
            String suggestedURL = theBurritoPlace.getBurritoShopURL();
            Log.i("shop", suggestedBurritoPlace);
            Log.i("url", suggestedURL);
            //create an Intent
            Intent intent = new Intent(this, ReceiveBurrito.class);

            //pass data
            intent.putExtra("burritoShop", suggestedBurritoPlace);
            intent.putExtra("burritoShopURL", suggestedURL);

            //start intent
            startActivity(intent);
        }
        else{
            Context context = getApplicationContext();
            CharSequence textToast = "Please fill out burrito info and hit build to find";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, textToast, duration);
            toast.show();
        }
    }
}
