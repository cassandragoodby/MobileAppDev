package com.example.cassandragoodby.finalgoodby;

/**
 * Created by CassandraGoodby on 12/17/17.
 */

public class burritoPlace {
    private String burritoShop;
    private String burritoShopURL;

    private void setBurritoInfo(Integer burritoPlace){
        switch (burritoPlace){
            case 0: //popular
                burritoShop="Illegal Petes";
                burritoShopURL="http://illegalpetes.com/";
                break;
            case 1: //cycling
                burritoShop="Chipotle";
                burritoShopURL="https://www.chipotle.com/";
                break;
            case 2: //hipster
                burritoShop="Bartaco";
                burritoShopURL="https://bartaco.com/";
                break;
            default:
                burritoShop="none";
                burritoShopURL="https://www.google.com/search?q=boulder+burrito+places&oq=boulder+burrito+places&aqs=chrome..69i57j69i64.4377j0j1&sourceid=chrome&ie=UTF-8";
        }
    }

    public void setBurritoShop(Integer burritoPlace){

        setBurritoInfo(burritoPlace);
    }

    public void setBurritoShopURL(Integer burritoPlace){

        setBurritoInfo(burritoPlace);
    }

    public String getBurritoShop(){

        return burritoShop;
    }

    public String getBurritoShopURL(){

        return burritoShopURL;
    }
}
