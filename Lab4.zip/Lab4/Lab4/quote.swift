//
//  quote.swift
//  Lab4
//
//  Created by Cassandra Goodby on 10/18/17.
//  Copyright © 2017 Cassandra Goodby. All rights reserved.
//

import Foundation
class quote {
    var quoteCnt : String?
    var quoteeName : String?
}
