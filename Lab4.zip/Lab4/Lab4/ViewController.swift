//
//  ViewController.swift
//  Lab4
//
//  Created by Cassandra Goodby on 10/18/17.
//  Copyright © 2017 Cassandra Goodby. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var info = quote()
    
    @IBOutlet weak var quoteFill: UILabel!
    @IBOutlet weak var quoteefill: UILabel!
    
    let filename = "quote.plist"
    
    @IBAction func unwindSegue (_ segue:UIStoryboardSegue){
        quoteFill.text=info.quoteCnt
        quoteefill.text=info.quoteeName
    }

    func docFilePath(_ filename: String) -> String?{
        //locate the documents directory
        let path = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.allDomainsMask, true)
        let dir = path[0] as NSString //document directory
        //creates the full path to our data file
        print(dir.appendingPathComponent(filename))
        return dir.appendingPathComponent(filename)
    }

    override func viewDidLoad() {
        let filePath = docFilePath(filename) //path to data file
        //if the data file exists, use it
        if FileManager.default.fileExists(atPath: filePath!){
            let path = filePath
            //load the data of the plist file into a dictionary
            let dataDictionary = NSDictionary(contentsOfFile: path!) as!
                [String:String]
            if dataDictionary.keys.contains("quote") {
                info.quoteCnt = dataDictionary["quote"]
                quoteFill.text=info.quoteCnt
            }
            //load favorite author
            if dataDictionary.keys.contains("quotee") {
                info.quoteeName = dataDictionary["quotee"]
                quoteefill.text=info.quoteeName
            }
        
        }
        //application instance
        let app = UIApplication.shared
        
        NotificationCenter.default.addObserver(self, selector: #selector(UIApplicationDelegate.applicationWillResignActive(_:)), name: NSNotification.Name(rawValue: "UIApplicationWillResignActiveNotification"), object: app)
        
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func applicationWillResignActive(_ notification: Notification){
        let filePath = docFilePath(filename)
        let data = NSMutableDictionary()
        //adds
        if info.quoteCnt != nil{
            data.setValue(info.quoteCnt, forKey: "quote")
        }
        if info.quoteeName != nil{
            data.setValue(info.quoteeName, forKey: "quotee")
        }
        //write the contents of the array to our plist file
        data.write(toFile: filePath!, atomically: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

