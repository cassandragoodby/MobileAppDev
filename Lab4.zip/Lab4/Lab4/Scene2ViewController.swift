//
//  Scene2ViewController.swift
//  Lab4
//
//  Created by Cassandra Goodby on 10/18/17.
//  Copyright © 2017 Cassandra Goodby. All rights reserved.
//

import UIKit

class Scene2ViewController: UIViewController, UITextFieldDelegate {
    @IBOutlet weak var quoteField: UITextField!
    @IBOutlet weak var quoteeField: UITextField!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "doneQuote"{
            let scene1ViewController = segue.destination as! ViewController
            //check to see that text was entered in the textfields
            if quoteField.text!.isEmpty == false{
                let quoteFix : String = quoteField.text!
                quoteField.text!.insert("\"", at: quoteFix.endIndex)
                quoteField.text!.insert("\"", at: quoteFix.startIndex)
//                quoteField.text!.insert("\"", at: quoteFix.endIndex)
                scene1ViewController.info.quoteCnt=quoteField.text!
            }
            if quoteeField.text!.isEmpty == false{
                let quoteeFix : String = quoteeField.text!
                quoteeField.text!.insert("-", at:quoteeFix.startIndex);
                scene1ViewController.info.quoteeName=quoteeField.text
            }
        }
    }
    
    

    override func viewDidLoad() {
        quoteField.delegate=self
        quoteeField.delegate=self
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
