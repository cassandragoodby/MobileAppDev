package com.example.cassandragoodby.lab5v1;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void changeName(View view){
        TextView choose = (TextView)findViewById(R.id.textView2);
        EditText name = (EditText)findViewById(R.id.editText);
        String nameValue = name.getText().toString();
        ImageView housePicture=(ImageView)findViewById(R.id.imageView);


        if(nameValue.isEmpty()){
            //toast
            Context context = getApplicationContext();
            CharSequence text = "Please enter your name";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }

        else {
            TextView hideThis = (TextView) findViewById(R.id.textView4);
            TextView hideThis2 = (TextView) findViewById(R.id.textView5);
            RadioGroup hideThis3 = (RadioGroup) findViewById(R.id.radioGroup);
            Spinner spinner = (Spinner) findViewById(R.id.spinner);
            String magicChoice = String.valueOf(spinner.getSelectedItem());

            RadioGroup element = (RadioGroup) findViewById(R.id.radioGroup);
            int elementChoice = element.getCheckedRadioButtonId();

            if (elementChoice == R.id.radioButton || elementChoice == R.id.radioButton2 || elementChoice == R.id.radioButton3 || elementChoice == R.id.radioButton4) {

                choose.setText(nameValue + " You're House" + " Is");
                name.setVisibility(View.INVISIBLE);

                Button hideThis5 = (Button) findViewById(R.id.button);
                Button showThis = (Button) findViewById(R.id.button2);
                ImageView showThis2 = (ImageView) findViewById(R.id.imageView);
                hideThis.setVisibility(View.INVISIBLE);
                hideThis2.setVisibility(View.INVISIBLE);
                hideThis3.setVisibility(View.INVISIBLE);
                spinner.setVisibility(View.INVISIBLE);
                hideThis5.setVisibility(View.INVISIBLE);
                showThis.setVisibility(View.VISIBLE);
                showThis2.setVisibility(View.VISIBLE);

                TextView houseText = (TextView) findViewById(R.id.textView6);


                switch (magicChoice) {
                    case "Of Course":
                        if (elementChoice == R.id.radioButton2) {
                            houseText.setText("Gryffindor");
                            housePicture.setImageResource(R.drawable.gryffindor);
                        } else if (elementChoice == R.id.radioButton3) {
                            houseText.setText("Hufflepuff");
                            housePicture.setImageResource(R.drawable.hufflepuff);
                        } else if (elementChoice == R.id.radioButton4) {
                            houseText.setText("Ravenclaw");
                            housePicture.setImageResource(R.drawable.ravenclaw);
                        } else if (elementChoice == R.id.radioButton) {
                            houseText.setText("Slytherin");
                            housePicture.setImageResource(R.drawable.slytherin);
                        }
                        break;
                    case "Kind Of":
                        if (elementChoice == R.id.radioButton2) {
                            houseText.setText("Gryffindor");
                            housePicture.setImageResource(R.drawable.gryffindor);
                        } else if (elementChoice == R.id.radioButton3) {
                            houseText.setText("Hufflepuff");
                            housePicture.setImageResource(R.drawable.hufflepuff);
                        } else if (elementChoice == R.id.radioButton4) {
                            houseText.setText("Ravenclaw");
                            housePicture.setImageResource(R.drawable.ravenclaw);
                        } else if (elementChoice == R.id.radioButton) {
                            houseText.setText("Slytherin");
                            housePicture.setImageResource(R.drawable.slytherin);
                        }
                        break;
                    case "Nope":
                        houseText.setText("Sorry You Have to Believe");
                        housePicture.setImageResource(R.drawable.sorry);
                }
            }

            else{
                Context context = getApplicationContext();
                CharSequence text = "Please Choose What's Most Important";
                int duration = Toast.LENGTH_SHORT;
                Toast toast = Toast.makeText(context, text, duration);
                toast.show();
            }

        }



    }

    public void reset(View view){
        TextView choose = (TextView)findViewById(R.id.textView2);
        EditText name = (EditText)findViewById(R.id.editText);
        name.setText("");
        String nameValue = name.getText().toString();
        choose.setText("Choose Wisely");
        TextView hideThis = (TextView)findViewById(R.id.textView4);
        TextView hideThis2 = (TextView)findViewById(R.id.textView5);
        RadioGroup hideThis3 = (RadioGroup)findViewById(R.id.radioGroup);
        hideThis3.clearCheck();
        Spinner hideThis4 = (Spinner)findViewById(R.id.spinner);
        hideThis4.setSelection(0);
        Button hideThis5 = (Button)findViewById(R.id.button);
        Button showThis = (Button)findViewById(R.id.button2);
        ImageView showThis2 = (ImageView)findViewById(R.id.imageView);
        TextView houseText = (TextView)findViewById(R.id.textView6);
        houseText.setText("Which House?");
        name.setVisibility(View.VISIBLE);
        hideThis.setVisibility(View.VISIBLE);
        hideThis2.setVisibility(View.VISIBLE);
        hideThis3.setVisibility(View.VISIBLE);
        hideThis4.setVisibility(View.VISIBLE);
        hideThis5.setVisibility(View.VISIBLE);
        showThis.setVisibility(View.INVISIBLE);
        showThis2.setVisibility(View.INVISIBLE);
    }

}
