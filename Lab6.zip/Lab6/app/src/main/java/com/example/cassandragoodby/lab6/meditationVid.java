package com.example.cassandragoodby.lab6;

/**
 * Created by CassandraGoodby on 12/7/17.
 */

public class meditationVid {
    private String meditationVid;
    private String medVidURL;

    private void setVidInfo(Integer meditationInfo){
        switch (meditationInfo){
            case 0: //popular
                meditationVid="Guided Meditation for Test Anxiety";
                medVidURL="https://www.youtube.com/watch?v=AtF0T2fPvbI";
                break;
            case 1: //cycling
                meditationVid="Guided Meditation for Work Anxiety";
                medVidURL="https://www.youtube.com/watch?v=64UkA5h6yRM";
                break;
            case 2: //hipster
                meditationVid="Guided Meditation for Relationship Issues";
                medVidURL="https://www.youtube.com/watch?v=30g9qWQf6GE";
                break;
            case 3: //tea
                meditationVid="General Guided Meditation";
                medVidURL="https://www.youtube.com/watch?v=Jyy0ra2WcQQ";
                break;
            case 4: //hippie
                meditationVid="Guided Meditation for Sleep Issues";
                medVidURL="https://www.youtube.com/watch?v=DEfgiRorfbM";
                break;
            default:
                meditationVid="none";
                medVidURL="https://www.google.com/search?ei=V5ApWvHnIsrBjwSpzK6IBw&q=guided+meditation&oq=Guided+Medi&gs_l=psy-ab.3.0.0i131k1j0i20i264k1j0i131i20i264k1j0l7.866.3025.0.3703.13.10.0.0.0.0.478.1674.2-2j2j1.5.0....0...1.1.64.psy-ab..8.5.1659...0i67k1j0i3k1j0i10k1.0.n39mkVDgNiQ";
        }
    }

    public void setMeditationVid(Integer meditationInfo){

        setVidInfo(meditationInfo);
    }

    public void setMeditationVidURL(Integer meditationInfo){

        setVidInfo(meditationInfo);
    }

    public String getMedVid(){

        return meditationVid;
    }

    public String getMedVidURL(){

        return medVidURL;
    }
}
