package com.example.cassandragoodby.lab6;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainRecieve extends AppCompatActivity {

    private String meditationVid;
    private String medVidURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_recieve);

        Intent intent = getIntent();
        meditationVid = intent.getStringExtra("vidName");
        medVidURL = intent.getStringExtra("vidURL");
        Log.i("vid received", meditationVid);
        Log.i("url received", medVidURL);

        TextView messageView = (TextView) findViewById(R.id.textView3);
        messageView.setText("Watch this " + meditationVid);



        final ImageButton imageButton = (ImageButton) findViewById(R.id.imageButton);
        View.OnClickListener onclick2 = new View.OnClickListener(){
            public void onClick(View view){
                loadWebSite(view);
            }
        };

        imageButton.setOnClickListener(onclick2);
    }

    public void loadWebSite(View view){
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(medVidURL));
        startActivity(intent);
    }

}
