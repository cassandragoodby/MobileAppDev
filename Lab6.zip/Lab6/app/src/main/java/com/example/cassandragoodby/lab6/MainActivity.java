package com.example.cassandragoodby.lab6;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    private meditationVid theMedVid = new meditationVid();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button button = (Button) findViewById(R.id.button);
        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                findVid(view);
            }
        };
        button.setOnClickListener(onclick);
    }

    public void findVid(View view){
        Spinner medSpinner = (Spinner)findViewById(R.id.spinner);
        Integer stressor = medSpinner.getSelectedItemPosition();
        theMedVid.setMeditationVid(stressor);
        String suggestedVid = theMedVid.getMedVid();
        String suggestedVidURL = theMedVid.getMedVidURL();
        Log.i("vid", suggestedVid);
        Log.i("url", suggestedVidURL);

        Intent intent = new Intent(this, MainRecieve.class);

        intent.putExtra("vidName", suggestedVid);
        intent.putExtra("vidURL", suggestedVidURL);

        startActivity(intent);
    }
}
