//
//  ViewController.swift
//  Midterm
//
//  Created by Cassandra Goodby on 10/19/17.
//  Copyright © 2017 Cassandra Goodby. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate  {
    @IBOutlet weak var roundTrip: UITextField!
    @IBOutlet weak var monthlycmt: UIStackView!
    @IBOutlet weak var gasInTank: UISlider!
    
    @IBAction func chooseTrans2(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex{
        case 0:
            transpic.image = UIImage(named: "car");
            var tripAmount:Float
            
            if(roundTrip.text!.isEmpty){
                tripAmount=0.0
                
            }
            else{
                tripAmount = Float(roundTrip.text!)!
            }
            
            let totalTimeAmt=tripAmount/20*60
            let gradeFormatter = NumberFormatter()
            gradeFormatter.numberStyle=NumberFormatter.Style.none
            totaltime.text=gradeFormatter.string(from: NSNumber(value: totalTimeAmt))
            let gasNeedSoon = tripAmount / 24*(5*4)
            let gradeFormatter2 = NumberFormatter()
            gradeFormatter2.numberStyle=NumberFormatter.Style.decimal
            gastopurch.text=gradeFormatter2.string(from: NSNumber(value: gasNeedSoon))
        case 1:
            transpic.image = UIImage(named: "bus");
            var tripAmount:Float
            
            if(roundTrip.text!.isEmpty){
                tripAmount=0.0
                
            }
            else{
                tripAmount = Float(roundTrip.text!)!
            }
            
            let totalTimeAmt=tripAmount/20*60
            let gradeFormatter = NumberFormatter()
            gradeFormatter.numberStyle=NumberFormatter.Style.none
            totaltime.text=gradeFormatter.string(from: NSNumber(value: totalTimeAmt))
            let gasNeedSoon = 0
            let gradeFormatter2 = NumberFormatter()
            gradeFormatter2.numberStyle=NumberFormatter.Style.decimal
            gastopurch.text=gradeFormatter2.string(from: NSNumber(value: gasNeedSoon))
        case 2:
            var tripAmount:Float
            
            if(roundTrip.text!.isEmpty){
                tripAmount=0.0
                
            }
            else{
                tripAmount = Float(roundTrip.text!)!
            }

            transpic.image = UIImage(named: "bike");
            let totalTimeAmt=tripAmount/10*60
            let gradeFormatter = NumberFormatter()
            gradeFormatter.numberStyle=NumberFormatter.Style.none
            totaltime.text=gradeFormatter.string(from: NSNumber(value: totalTimeAmt))
            let gasNeedSoon = 0
            let gradeFormatter2 = NumberFormatter()
            gradeFormatter2.numberStyle=NumberFormatter.Style.decimal
            gastopurch.text=gradeFormatter2.string(from: NSNumber(value: gasNeedSoon))
        default:
            break
        }
    }

    
    @IBAction func monthAmt(_ sender: UISwitch) {
        if (sender.isOn == true){
            var tripAmount:Float
            
            if(roundTrip.text!.isEmpty){
                tripAmount=0.0
                
            }
            else{
                tripAmount = Float(roundTrip.text!)!
            }
            
            let totalTimeAmt=tripAmount/20*60*(5*4)
            let gradeFormatter = NumberFormatter()
            gradeFormatter.numberStyle=NumberFormatter.Style.none
            totaltime.text=gradeFormatter.string(from: NSNumber(value: totalTimeAmt))
            let gasNeedSoon = tripAmount / 24*(5*4)
            let gradeFormatter2 = NumberFormatter()
            gradeFormatter2.numberStyle=NumberFormatter.Style.decimal
            gastopurch.text=gradeFormatter2.string(from: NSNumber(value: gasNeedSoon))
        }
        else{
            var tripAmount:Float
            
            if(roundTrip.text!.isEmpty){
                tripAmount=0.0
                
            }
            else{
                tripAmount = Float(roundTrip.text!)!
            }
            
            let totalTimeAmt=tripAmount/20*60
            let gradeFormatter = NumberFormatter()
            gradeFormatter.numberStyle=NumberFormatter.Style.none
            totaltime.text=gradeFormatter.string(from: NSNumber(value: totalTimeAmt))
            let gasNeedSoon = tripAmount / 24
            let gradeFormatter2 = NumberFormatter()
            gradeFormatter2.numberStyle=NumberFormatter.Style.decimal
            gastopurch.text=gradeFormatter2.string(from: NSNumber(value: gasNeedSoon))
        }
    }
    
    @IBAction func gasTank(_ sender: UISlider) {
        let currentGas = Int(sender.value);
        gasNum.text = "\(currentGas)";
        
    }
    
    @IBOutlet weak var gasNum: UILabel!
    @IBOutlet weak var totaltime: UILabel!
    @IBOutlet weak var gastopurch: UILabel!
    @IBOutlet weak var transpic: UIImageView!
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        roundTrip.resignFirstResponder()
        return true
    }
    
    func updateCommuteTime(){
        var tripAmount:Float
        
        if(roundTrip.text!.isEmpty){
            tripAmount=0.0
    
        }
        else{
            tripAmount = Float(roundTrip.text!)!
        }
        
        let totalTimeAmt=tripAmount/20*60
        let gradeFormatter = NumberFormatter()
        gradeFormatter.numberStyle=NumberFormatter.Style.none
        totaltime.text=gradeFormatter.string(from: NSNumber(value: totalTimeAmt))
        let gasNeedSoon = tripAmount / 24
        let gradeFormatter2 = NumberFormatter()
        gradeFormatter2.numberStyle=NumberFormatter.Style.decimal
        gastopurch.text=gradeFormatter2.string(from: NSNumber(value: gasNeedSoon))
    }
    
    func updateGasAmount(){
        
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        updateCommuteTime()
        
    }
    
    override func viewDidLoad() {
        roundTrip.delegate=self
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func textFieldDoneEditing(sender: UITextField) {
        sender.resignFirstResponder()
            }
    @IBAction func onTapGetsureRecognized(_ sender: Any) {
    roundTrip.resignFirstResponder()
    }
    


}

