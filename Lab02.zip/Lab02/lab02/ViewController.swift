//
//  ViewController.swift
//  lab02
//
//  Created by Cassandra Goodby on 9/19/17.
//  Copyright © 2017 Cassandra Goodby. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var weatherLabel: UILabel!
    
    @IBOutlet weak var wordLabel: UILabel!
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    
    @IBOutlet weak var whiteImg: UIImageView!
    
    @IBOutlet weak var backgroundImg: UIImageView!
    
    @IBAction func weatherChoice(_ sender: UISegmentedControl) {
        switch segmentedControl.selectedSegmentIndex
        {
        case 0:
            whiteImg.image = UIImage(named: "sunimg");
            backgroundImg.image = UIImage(named: "orangebg");
            wordLabel.text=wordLabel.text?.uppercased();
            
        case 1:
            whiteImg.image = UIImage(named: "rainimg");
            backgroundImg.image = UIImage(named: "bluebg");
            wordLabel.text=wordLabel.text?.lowercased();
        default:
            break; 
        }
    }
    
    @IBAction func tempChoice(_ sender: UISlider) {
        let currentTemp = Int(sender.value);
        weatherLabel.text = "\(currentTemp)°";
        
        if(currentTemp >= 0 && currentTemp < 40){
             wordLabel.text = "Cold";
            wordLabel.font = UIFont(name: wordLabel.font.fontName, size: 20);
            weatherLabel.textColor = UIColor.blue;
        }
        else if(currentTemp > 40 && currentTemp < 70){
            wordLabel.text = "Nice";
            wordLabel.font = UIFont(name: wordLabel.font.fontName, size: 30);
            weatherLabel.textColor = UIColor.white;
        }
        else{
            wordLabel.font = UIFont(name: wordLabel.font.fontName, size: 40);
            wordLabel.text = "Hot";
            weatherLabel.textColor = UIColor.orange;
        }
    }
    
    @IBAction func labelChoice(_ sender: UISwitch) {
        if (sender.isOn == true){
            wordLabel.isHidden = false;
        }
        else{
            wordLabel.isHidden = true;
        }
        }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

