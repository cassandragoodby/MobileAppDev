//
//  ViewController.swift
//  lab3
//
//  Created by Cassandra Goodby on 10/9/17.
//  Copyright © 2017 Cassandra Goodby. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var grade1amount: UITextField!
    @IBOutlet weak var grade1weight: UITextField!
    @IBOutlet weak var grade2amount: UITextField!
    @IBOutlet weak var grade2weight: UITextField!
    @IBOutlet weak var grade3amount: UITextField!
    @IBOutlet weak var grade3weight: UITextField!
    
    
    @IBOutlet weak var aveGrade: UILabel!
    
    @IBOutlet weak var currentGrade: UILabel!
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        grade1amount.resignFirstResponder()
        grade1weight.resignFirstResponder()
        grade2amount.resignFirstResponder()
        grade2weight.resignFirstResponder()
        grade3amount.resignFirstResponder()
        grade3weight.resignFirstResponder()
        return true
    }
    
    
    
    func updateCurrentGrade(){
        
        
        var gradeOne:Float
        var gradeOneW:Float
        var gradeTwo:Float
        var gradeTwoW:Float
        var gradeThree:Float
        var gradeThreeW:Float
        
        
        
        
        if(grade1amount.text!.isEmpty){
            gradeOne=0.0
        }
        else{
            gradeOne = Float(grade1amount.text!)!
        }
        if(grade1weight.text!.isEmpty){
            gradeOneW=0.0
        }
        else{
            gradeOneW = Float(grade1weight.text!)!
        }
        if(grade2amount.text!.isEmpty){
            gradeTwo=0.0
        }
        else{
            gradeTwo = Float(grade2amount.text!)!
        }
        if(grade2weight.text!.isEmpty){
            gradeTwoW=0.0
        }
        else{
            gradeTwoW = Float(grade2weight.text!)!
        }
        if(grade3amount.text!.isEmpty){
            gradeThree=0.0
        }
        else{
            gradeThree = Float(grade3amount.text!)!
        }
        if(grade3weight.text!.isEmpty){
            gradeThreeW=0.0
        }
        else{
            gradeThreeW = Float(grade3weight.text!)!
        }
    
        
        if(gradeOne <= 100 && gradeTwo <= 100 && gradeThree <= 100 && gradeOneW <= 100 && gradeTwoW <= 100 && gradeThreeW <= 100){
                if(gradeOneW+gradeTwoW+gradeThreeW <= 100){
                    let averageGradeAmount = ((gradeOne/100*(gradeOneW/100))+(gradeTwo/100*(gradeTwoW/100))+(gradeThree/100*(gradeThreeW/100)))/(gradeOneW/100+gradeTwoW/100+gradeThreeW/100)
                    let currentGradeAmount =  (gradeOne/100*(gradeOneW/100))+(gradeTwo/100*(gradeTwoW/100))+(gradeThree/100*(gradeThreeW/100))
//                    let neededGrade = ((gradeOneW/100)+(gradeTwoW/100)+(gradeThreeW/100))
                    
                   
                    
//            currentGrade.text = currentGradeAmount;
                    let gradeFormatter = NumberFormatter()
                    gradeFormatter.numberStyle=NumberFormatter.Style.percent
                    //        currentGrade.text = currentGradeAmount;
                    if(grade3weight.text!.isEmpty || grade1amount.text!.isEmpty || grade2amount.text!.isEmpty || grade3amount.text!.isEmpty || grade1weight.text!.isEmpty || grade2weight.text!.isEmpty){
//                        updateCurrentGrade()
                    }
                    else{
                    currentGrade.text=gradeFormatter.string(from: NSNumber(value: currentGradeAmount))
                    aveGrade.text=gradeFormatter.string(from: NSNumber(value: averageGradeAmount))
            

                    }
                }
                else{
                    let alert=UIAlertController(title: "Warning", message: "Grade weights added together must equal less than 100. All grade weights reset to 0", preferredStyle: UIAlertControllerStyle.alert)
                    let cancelAction=UIAlertAction(title: "Cancel", style:UIAlertActionStyle.cancel, handler: nil)
                    alert.addAction(cancelAction)
                    let okAction=UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: {action in
                        
                        self.grade1weight.text="0"
                        self.grade2weight.text="0"
                        self.grade3weight.text="0"
                        self.updateCurrentGrade()
                    })
                    alert.addAction(okAction)
                    present(alert, animated: true, completion: nil)
            }
        }
            
            
        else{
            let alert=UIAlertController(title: "Warning", message: "All grades and grade weights must be less than 100", preferredStyle: UIAlertControllerStyle.alert)
            let cancelAction=UIAlertAction(title: "Cancel", style:UIAlertActionStyle.cancel, handler: nil)
            alert.addAction(cancelAction)
            let okAction=UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: {action in
                if(gradeOne > 100){
                    self.grade1amount.text="0"
                }
                if(gradeOneW >= 100){
                    self.grade1weight.text="0"
                    self.grade2weight.text="0"
                    self.grade3weight.text="0"
                }
                if(gradeTwo > 100){
                    self.grade2amount.text="0"
                }
                if(gradeThree >= 100){
                    self.grade3amount.text="0"
                }
                if(gradeTwoW > 100){
                    self.grade1weight.text="0"
                    self.grade2weight.text="0"
                    self.grade3weight.text="0"
                }
                if(gradeThreeW >= 100){
                    self.grade1weight.text="0"
                    self.grade2weight.text="0"
                    self.grade3weight.text="0"
                }

            })
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
        }
        
            
//        else{
//            let alert=UIAlertController(title: "Warning", message: "To receive % needed on the final weights of grade one, two and three must equal less than 100", preferredStyle: UIAlertControllerStyle.alert)
//            let cancelAction=UIAlertAction(title: "Cancel", style:UIAlertActionStyle.cancel, handler: nil)
//            alert.addAction(cancelAction)
//            let okAction=UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: {action in
//                
//                
//                self.updateCurrentGrade()
//            })
//            alert.addAction(okAction)
//            present(alert, animated: true, completion: nil)
//        }
    
    }

    func textFieldDidEndEditing(_ textField: UITextField) {
        
        updateCurrentGrade()
        
    }
    
    
    
    
    override func viewDidLoad() {
        grade1amount.delegate=self
        grade1weight.delegate=self
        grade2amount.delegate=self
        grade2weight.delegate=self
        grade3amount.delegate=self
        grade3weight.delegate=self
        aveGrade.layer.masksToBounds = true
        aveGrade.layer.cornerRadius = 5.0
        currentGrade.layer.masksToBounds = true
        currentGrade.layer.cornerRadius = 5.0
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func textFieldDoneEditing(sender: UITextField) {
        sender.resignFirstResponder()
    }
    @IBAction func onTapGestureRecognized(_ sender: Any) {
        grade1amount.resignFirstResponder()
        grade2amount.resignFirstResponder()
        grade3amount.resignFirstResponder()
        grade1weight.resignFirstResponder()
        grade2weight.resignFirstResponder()
        grade3weight.resignFirstResponder()
    }
    
}

